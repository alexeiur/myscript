# VK Autopost — готовые файлы

В архиве лежит:
- `index_plus_friends.html` — основная страница (3 аккаунта, постинг, друзья, «вечный онлайн»).
- `index_plus_friends_diag.html` — диагностика сети/токена.
- `server.js`, `package.json` — минимальный Node‑прокси для обхода CORS/блокировщиков (по желанию).

## Вариант A — GitHub Pages / любой статический хостинг
1. Залей `index_plus_friends.html` в корень и назови `index.html`.
2. Открой страницу по HTTPS.
3. Вставь user‑токен со скоупами: `friends, wall, photos, groups, offline`.
4. Жми «Проверить токен» → «Проверить методы друзей» → «Старт».

## Вариант B — открыть локально
Запусти простой http‑сервер в папке с файлом:
```
python -m http.server 8000
```
Открой `http://localhost:8000/index_plus_friends.html`

## Вариант C — свой VPS (обход CORS)
1. Скопируй `server.js` и `package.json` на сервер.
2. Установи Node 18+ и зависимости:
```
npm i --production
npm start
```
3. Теперь на фронте можно использовать прокси:
   - В консоли браузера:
     ```js
     localStorage.vk_proxy = 'http://<твой-домен>:3000';
     ```
   - И заменить базовый URL в коде на `localStorage.vk_proxy || 'https://api.vk.com'`.
4. Проверь: `http://<домен>:3000/vk?method=utils.getServerTime&v=5.199` должен вернуть время сервера.

## Памятка
- Для сообществ `owner_id` отрицательный (например `-12345678`), для профиля — положительный.
- Лимиты VK: если словил `Too many requests per second (code 6)` — подожди, у нас есть ретраи/паузы.
- Капча (code 14) — страница покажет окно, введи символы и скрипт продолжит.
