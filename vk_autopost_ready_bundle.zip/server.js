/* Minimal VK proxy to bypass CORS/adblock (Node 18+ recommended) */
const express = require('express');
const app = express();

app.get('/vk', async (req, res) => {
  const { method, ...params } = req.query;
  if (!method) return res.status(400).json({ error: 'method required' });
  const qs = new URLSearchParams(params).toString();
  const url = `https://api.vk.com/method/${method}?${qs}`;
  try {
    const r = await fetch(url);
    const text = await r.text();
    res.set('content-type', 'application/json').send(text);
  } catch (e) {
    res.status(502).json({ error: 'upstream_fetch_failed', message: String(e) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('VK proxy on http://localhost:'+PORT+'/vk?method=utils.getServerTime&v=5.199'));
