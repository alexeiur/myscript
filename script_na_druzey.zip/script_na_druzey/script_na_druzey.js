#!/usr/bin/env node
"use strict";

// Загружаем переменные окружения из файла .env
require("dotenv").config();

const fetch = require("node-fetch");

// 1. Чтение основных конфигурационных параметров
const TOKEN = process.env.TOKEN || "ваш_токен_доступа";
const API_VERSION = process.env.API_VERSION || "5.131";

// 2. Конфигурация групп и текстов постов
const GROUP_IDS = [
  12345678, 23456789, 34567890, 45678901, 56789012,
  67890123, 78901234, 89012345, 90123456
];

const POST_TEXTS = [
  "👋 Привет! Добавь меня в друзья — вместе интереснее! 🤝",
    "✨ Хочешь новых знакомств? Добавляй в друзья! 🚀",
    "😊 Дружба — это сила! Не стесняйся, добавь в друзья! 💬",
    "👫 Давай станем друзьями! Жду твою заявку! 📩",
    "🔥 Добавь в друзья и будь в курсе всех новостей! 📲",
    "🌟 Вместе веселее — добавляй меня в друзья! 🎉",
    "🤗 Открыт для новых друзей! Нажми ‘Добавить в друзья’! ➕",
    "📢 Друзья — это поддержка! Добавь меня в друзья и убедись! 💪",
    "💡 Ищешь новых знакомств? Просто добавь в друзья! 🌈",
    "🎈 Не упусти шанс — добавь меня в друзья сегодня! ⏳",
    "🚀 Присоединяйся к моим друзьям — будет интересно! 🛸",
    "🌍 Мир большой, а друзья — ещё больше! Добавляйся! 🌟",
    "🤩 Добавь меня в друзья и давай общаться чаще! 🗨️",
    "🎉 Новые друзья — новые возможности! Жду заявку! 📨",
    "📱 Просто добавь в друзья и будь на связи всегда! 🔗",
    "✨ Будем дружить! Нажми ‘Добавить в друзья’ сейчас! 👆",
    "😊 Добавляйся в друзья и делись хорошим настроением! ☀️",
    "🤝 Чем больше друзей — тем ярче жизнь! Добавь меня! 🎨",
    "🌟 Добавь в друзья и открой новые горизонты общения! 🗺️",
    "💬 Хочешь классных друзей? Начни с добавления меня! 🙌",
    "🎉 Привет! Давай дружить! Множество интересных разговоров впереди! 🎊",
    "🤗 Добавляйся в друзья! Кто знает, возможно, у нас будет много общих интересов! 💬",
    "🌟 Не упускай возможность расширить круг друзей. Добавь меня! 🚀",
    "🎈 Никаких ограничений, только дружба! Добавляй в друзья и общайся на все темы! 💬",
    "🚀 Будь в курсе всех интересных событий! Добавляй в друзья и оставайся на связи! 📲"
];

// 3. Объект для сбора статистики
const stats = {
  publishedPosts: 0,
  acceptedFriendRequests: 0,
  onlineStatusUpdates: 0,
  totalApiAttempts: 0,
  totalRetries: 0,
  failedRequests: 0
};

// 4. Параметры повторных попыток (ретраев)
const MAX_RETRIES = 3;
const BASE_DELAY_MS = 500; // базовая задержка для back-off в мс

// 5. Задержка между постами (рекомендуемая задержка)
const POST_DELAY_MS = process.env.POST_DELAY_MS ? parseInt(process.env.POST_DELAY_MS, 10) : 2000; // по умолчанию 2 секунды

// 6. Функция задержки с экспоненциальным back-off
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 7. Простой кэш для заявок в друзья (TTL = 30 секунд)
const cache = {
  friendRequests: {
    data: null,
    timestamp: 0,
    ttl: 30000
  }
};

// 8. Функция для вызова методов VK API с экспоненциальным back-off и обработкой ошибок
async function vkApiCall(method, params = {}, retries = MAX_RETRIES) {
  const url = new URL(`https://api.vk.com/method/${method}`);
  url.searchParams.append("access_token", TOKEN);
  url.searchParams.append("v", API_VERSION);
  Object.entries(params).forEach(([key, value]) => url.searchParams.append(key, value));

  let attempt = 0;
  while (attempt <= retries) {
    stats.totalApiAttempts++;
    try {
      const response = await fetch(url.toString());
      const data = await response.json();

      if (data.error) {
        stats.failedRequests++;
        console.error(`Ошибка VK API (${method}), попытка ${attempt + 1}:`, data.error);
      } else {
        return data.response;
      }
    } catch (error) {
      stats.failedRequests++;
      console.error(`Ошибка при выполнении запроса ${method}, попытка ${attempt + 1}:`, error);
    }
    stats.totalRetries++;
    attempt++;
    const delayTime = BASE_DELAY_MS * Math.pow(2, attempt);
    await delay(delayTime);
  }
  return null;
}

// 9. Публикация случайных постов в группах с задержкой между публикациями (последовательно)
async function publishPosts() {
  for (const group of GROUP_IDS) {
    const message = POST_TEXTS[Math.floor(Math.random() * POST_TEXTS.length)];
    const params = { owner_id: -group, message };
    const result = await vkApiCall("wall.post", params);
    if (result) {
      console.log(`Пост в группе ${group} опубликован: "${message}"`);
      stats.publishedPosts++;
    } else {
      console.error(`Не удалось опубликовать пост в группе ${group}`);
    }
    // Задержка между публикациями
    console.log(`Ожидание ${POST_DELAY_MS} мс перед следующим постом...`);
    await delay(POST_DELAY_MS);
  }
}

// 10. Прием заявок в друзья с использованием кэширования
async function acceptFriendRequests() {
  let result;
  const now = Date.now();

  if (cache.friendRequests.data && (now - cache.friendRequests.timestamp) < cache.friendRequests.ttl) {
    result = cache.friendRequests.data;
    console.log("Используем кэшированные данные заявок в друзья.");
  } else {
    result = await vkApiCall("friends.getRequests");
    cache.friendRequests = {
      data: result,
      timestamp: now,
      ttl: cache.friendRequests.ttl
    };
  }

  if (result && result.items && result.items.length > 0) {
    for (const user_id of result.items) {
      const addResult = await vkApiCall("friends.add", { user_id });
      if (addResult) {
        console.log(`Принята заявка от пользователя ${user_id} 👍`);
        stats.acceptedFriendRequests++;
      } else {
        console.error(`Не удалось принять заявку от пользователя ${user_id}`);
      }
    }
  } else {
    console.log("Нет заявок в друзья для обработки.");
  }
}

// 11. Обновление статуса (в сети)
async function setOnline() {
  const result = await vkApiCall("status.set", { text: "Я в сети! 💻" });
  if (result) {
    console.log("Статус обновлён: Я в сети! 💻");
    stats.onlineStatusUpdates++;
  } else {
    console.error("Не удалось обновить статус.");
  }
}

// 12. Тестирование основных функций (запускается с параметром test)
async function runTests() {
  console.log("Запуск тестов...");

  const start = Date.now();
  await delay(1000);
  const elapsed = Date.now() - start;
  console.log(`Функция delay отработала за ~${elapsed} мс (ожидалось ~1000 мс)`);

  console.log("Проверка работы vkApiCall методом users.get...");
  const testResult = await vkApiCall("users.get", { user_ids: 1 });
  if (testResult) {
    console.log("Тестовый запрос успешно выполнен:", testResult);
  } else {
    console.error("Тестовый запрос не выполнен.");
  }

  console.log("Тесты завершены.\n");
}

// 13. Основная функция скрипта
async function main() {
  if (process.argv.includes("test")) {
    await runTests();
    return;
  }
  
  console.log("Запуск скрипта...");

  await publishPosts();
  await acceptFriendRequests();
  await setOnline();

  console.log("\nОтчёт по выполненным операциям:");
  console.log(`- Опубликовано постов: ${stats.publishedPosts}`);
  console.log(`- Принято заявок в друзья: ${stats.acceptedFriendRequests}`);
  console.log(`- Обновлений статуса: ${stats.onlineStatusUpdates}`);
  console.log(`- Общее количество попыток API: ${stats.totalApiAttempts}`);
  console.log(`- Общее количество ретраев: ${stats.totalRetries}`);
  console.log(`- Ошибочных запросов: ${stats.failedRequests}`);

  console.log("Скрипт завершил выполнение.");
}

// Запуск основной функции
(async () => {
  await main();
})();