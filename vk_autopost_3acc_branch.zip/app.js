// === Конфиг VK API и ограничения ===
const API_V = "5.199"; // SDK vk-java-sdk указывает 5.199 как актуальную схему
const CALL_DELAY_MS = 550; // ~2 rps с запасом
const MAX_RETRY = 4;

// Ключи для localStorage
const LS_HISTORY = "vk_history_v2"; // [{acc, owner_id, post_id, ts}]
const LS_USED = "vk_used_v2"; // уникальность по аккаунтам
const LS_CFG = "vk_cfg_v1"; // сохранение настроек

// Утилиты
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const randInt = (a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const shuffle = (arr)=>arr.map(v=>[Math.random(),v]).sort((a,b)=>a[0]-b[0]).map(x=>x[1]);
function log(el, ...args){ const s = args.map(x=>typeof x==="string"?x:JSON.stringify(x)).join(" "); el.textContent = `[${new Date().toLocaleTimeString()}] ${s}\n` + el.textContent; }
function loadJSON(key, def){ try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(def)); } catch { return def; } }
function saveJSON(key, val){ localStorage.setItem(key, JSON.stringify(val)); }

let historyPosts = loadJSON(LS_HISTORY, []);
let usedCache = loadJSON(LS_USED, { texts:{}, photos:{} });

// Капча диалог
const captchaDialog = document.getElementById("captchaDialog");
const captchaImg = document.getElementById("captchaImg");
const captchaKeyInput = document.getElementById("captchaKey");
function requestCaptcha(imgUrl){
  return new Promise((resolve,reject)=>{
    captchaImg.src = imgUrl;
    captchaKeyInput.value = "";
    captchaDialog.returnValue = "";
    captchaDialog.showModal();
    const onClose = () => {
      captchaDialog.removeEventListener("close", onClose);
      if (captchaDialog.returnValue === "ok") resolve(captchaKeyInput.value.trim());
      else reject(new Error("captcha cancelled"));
    };
    captchaDialog.addEventListener("close", onClose);
  });
}

// Троттлинг вызовов per token
const lastCallAtByToken = new Map();
async function rateGate(token){
  const last = lastCallAtByToken.get(token) || 0;
  const now = Date.now();
  const diff = now - last;
  if (diff < CALL_DELAY_MS) await sleep(CALL_DELAY_MS - diff);
  lastCallAtByToken.set(token, Date.now());
}

// VK API вызов с обработкой ошибок 6 (flood) и 14 (captcha)
async function vkCall(token, method, params={}, retry=0){
  await rateGate(token);
  const q = new URLSearchParams({ ...params, access_token: token, v: API_V });
  const url = `https://api.vk.com/method/${method}?` + q.toString();
  const res = await fetch(url);
  const json = await res.json();

  if (json.error){
    const e = json.error;

    // CAPTCHA needed (14)
    if (e.error_code === 14 && e.captcha_img && e.captcha_sid){
      try{
        const key = await requestCaptcha(e.captcha_img);
        return vkCall(token, method, { ...params, captcha_sid: e.captcha_sid, captcha_key: key }, retry+1);
      }catch(err){
        throw new Error(`CAPTCHA: отменено пользователем`);
      }
    }

    // Flood control (6) — экспоненциальный бэкофф
    if (e.error_code === 6 && retry < MAX_RETRY){
      const backoff = Math.min(4000, 600 * Math.pow(2, retry)) + randInt(100,700);
      await sleep(backoff);
      return vkCall(token, method, params, retry+1);
    }

    throw new Error(`VK API error ${e.error_code}: ${e.error_msg}`);
  }

  return json.response;
}

// Загрузка одной фотографии на стену
async function uploadWallPhoto(token, ownerId, file){
  const isGroup = Number(ownerId) < 0;
  const group_id = isGroup ? Math.abs(Number(ownerId)) : undefined;
  const up = await vkCall(token, "photos.getWallUploadServer", group_id?{group_id}:{});
  const fd = new FormData();
  fd.append("photo", file);
  const upRes = await fetch(up.upload_url, { method:"POST", body:fd }).then(r=>r.json());
  const saved = await vkCall(token, "photos.saveWallPhoto", {
    photo: upRes.photo, server: upRes.server, hash: upRes.hash, ...(group_id?{group_id}:{})
  });
  const ph = saved[0];
  return `photo${ph.owner_id}_${ph.id}`;
}

// Публикация поста
async function postToWall(token, ownerId, message, attachments){
  const params = { owner_id: Number(ownerId), message };
  if (attachments.length) params.attachments = attachments.join(",");
  if (Number(ownerId) < 0) params.from_group = 1;
  return vkCall(token, "wall.post", params);
}

// Удаление поста
async function deletePost(token, ownerId, postId){
  return vkCall(token, "wall.delete", { owner_id: Number(ownerId), post_id: postId });
}

// === UI и состояние ===
const accEls = [...document.querySelectorAll(".acc")].map(sec => ({
  root: sec,
  idx: Number(sec.dataset.index),
  token: sec.querySelector(".token"),
  owner: sec.querySelector(".owner"),
  texts: sec.querySelector(".texts"),
  photos: sec.querySelector(".photos"),
  photosPerPost: sec.querySelector(".photosPerPost"),
  ttlDays: sec.querySelector(".ttlDays"),
  intMin: sec.querySelector(".intMin"),
  intMax: sec.querySelector(".intMax"),
  quietHours: sec.querySelector(".quietHours"),
  startBtn: sec.querySelector(".start"),
  stopBtn: sec.querySelector(".stop"),
  postOnceBtn: sec.querySelector(".postOnce"),
  sweepBtn: sec.querySelector(".sweep"),
  log: sec.querySelector(".log")
}));
const runtime = accEls.map(()=>({ timer:null, running:false, lastMessage:"", lastPhotos:[] }));

// Сохранение/восстановление конфигурации
function saveCfg(){
  const cfg = accEls.map(el => ({
    token: el.token.value, owner: el.owner.value,
    texts: el.texts.value, photosPerPost: el.photosPerPost.value,
    ttlDays: el.ttlDays.value, intMin: el.intMin.value, intMax: el.intMax.value,
    quiet: el.quietHours.checked
  }));
  saveJSON(LS_CFG, cfg);
}
function restoreCfg(){
  const cfg = loadJSON(LS_CFG, null);
  if (!cfg) return;
  cfg.forEach((c,i)=>{
    const el = accEls[i];
    if (!el) return;
    el.token.value = c.token || "";
    el.owner.value = c.owner || "";
    el.texts.value = c.texts || "";
    el.photosPerPost.value = c.photosPerPost || 1;
    el.ttlDays.value = c.ttlDays || 3;
    el.intMin.value = c.intMin || 60;
    el.intMax.value = c.intMax || 120;
    el.quietHours.checked = !!c.quiet;
  });
}
setInterval(saveCfg, 2000);

// Уникальные выборки
function buildQueues(accEl){
  const texts = accEl.texts.value.split("\n").map(s=>s.trim()).filter(Boolean);
  const files = [...accEl.photos.files];
  const ppp = Math.max(0, Math.min(10, Number(accEl.photosPerPost.value||1)));

  const keyT = `acc${accEl.idx}`;
  const keyP = `acc${accEl.idx}`;

  const usedTexts = new Set(usedCache.texts[keyT] || []);
  let poolTexts = texts.filter(t=>!usedTexts.has(t));
  if (poolTexts.length === 0 && texts.length){
    // сброс, чтобы возобновить цикл без немедленных повторов
    usedCache.texts[keyT] = [];
    saveJSON(LS_USED, usedCache);
    poolTexts = texts.slice();
  }

  const usedPhotos = new Set(usedCache.photos[keyP] || []);
  let poolFiles = files.filter(f=>!usedPhotos.has(f.name));
  if (poolFiles.length === 0 && files.length){
    usedCache.photos[keyP] = [];
    saveJSON(LS_USED, usedCache);
    poolFiles = files.slice();
  }

  return { textQueue: shuffle(poolTexts), photoQueue: shuffle(poolFiles), ppp };
}

// Выбор времени с учётом «тихих часов» (01–06 местного времени машины)
function nextDelayMs(accEl){
  const minM = Number(accEl.intMin.value||60);
  const maxM = Number(accEl.intMax.value||120);
  const delayMin = Math.max(5, Math.min(minM, maxM));
  const delayMax = Math.max(delayMin, Math.max(minM, maxM));
  const mins = randInt(delayMin, delayMax);
  const base = mins*60*1000 + randInt(0,5000);

  if (!accEl.quietHours.checked) return base;

  // Если следующий пост попадает в 01:00–06:00 — перенесём на 06:05
  const now = new Date();
  const target = new Date(now.getTime()+base);
  const h = target.getHours();
  if (h >= 1 && h < 6){
    const six = new Date(target);
    six.setHours(6, 5, randInt(0,50), 0);
    return six.getTime() - now.getTime();
  }
  return base;
}

async function postOnce(accEl){
  const token = accEl.token.value.trim();
  const ownerId = accEl.owner.value.trim();
  if (!token || !ownerId){ log(accEl.log, "Заполните token/owner_id"); return; }

  const { textQueue, photoQueue, ppp } = buildQueues(accEl);
  const prevMessage = runtime[accEl.idx].lastMessage;

  // Текст
  let message = textQueue[0] || "";
  if (message && message === prevMessage && textQueue.length > 1){
    message = textQueue[1]; // избегаем немедленного повтора
  }
  // Отмечаем использованный текст
  if (message){
    const kT = `acc${accEl.idx}`;
    usedCache.texts[kT] = [...new Set([...(usedCache.texts[kT]||[]), message])];
    saveJSON(LS_USED, usedCache);
  }

  // Фото
  let pickedFiles = [];
  if (ppp > 0){
    if (photoQueue.length === 0){
      log(accEl.log, "Фотографий нет");
    } else {
      pickedFiles = photoQueue.slice(0, Math.min(ppp, photoQueue.length));
      const kP = `acc${accEl.idx}`;
      usedCache.photos[kP] = [...new Set([...(usedCache.photos[kP]||[]), ...pickedFiles.map(f=>f.name)])];
      saveJSON(LS_USED, usedCache);
    }
  }

  try{
    // Загрузим фото
    const attachments = [];
    for (const f of pickedFiles){
      const a = await uploadWallPhoto(token, ownerId, f);
      attachments.push(a);
    }
    // Публикация
    const res = await postToWall(token, ownerId, message, attachments);
    const post_id = res.post_id;
    historyPosts.push({ acc: accEl.idx, owner_id: Number(ownerId), post_id, ts: Date.now() });
    saveJSON(LS_HISTORY, historyPosts);
    runtime[accEl.idx].lastMessage = message;
    runtime[accEl.idx].lastPhotos = pickedFiles.map(f=>f.name);
    log(accEl.log, `OK: post_id=${post_id}`, attachments.length?`attachments=${attachments.length}`:"");
  }catch(e){
    log(accEl.log, `Ошибка: ${e.message}`);
  }
}

function scheduleNext(accEl){
  const r = runtime[accEl.idx];
  if (!r.running) return;
  const ms = nextDelayMs(accEl);
  const mins = Math.round(ms/60000);
  log(accEl.log, `Следующий пост через ~${mins} мин`);
  r.timer = setTimeout(async ()=>{
    await postOnce(accEl);
    scheduleNext(accEl);
  }, ms);
}

function startAcc(accEl){
  const r = runtime[accEl.idx];
  if (r.running) return;
  r.running = true;
  accEl.startBtn.disabled = true;
  accEl.stopBtn.disabled = false;
  scheduleNext(accEl);
}

function stopAcc(accEl){
  const r = runtime[accEl.idx];
  r.running = false;
  clearTimeout(r.timer);
  accEl.startBtn.disabled = false;
  accEl.stopBtn.disabled = true;
  log(accEl.log, "Остановлено");
}

async function sweepOld(accEl){
  const token = accEl.token.value.trim();
  const ttlDays = Number(accEl.ttlDays.value||3);
  const cutoff = Date.now() - ttlDays*24*60*60*1000;
  const rows = historyPosts.filter(h => h.acc === accEl.idx && h.ts <= cutoff);
  if (!token || rows.length===0){ log(accEl.log, rows.length? "Укажите токен": "Старых постов нет"); return; }
  let ok=0, fail=0;
  for (const h of rows){
    try{ await deletePost(token, h.owner_id, h.post_id); ok++; }
    catch(e){ fail++; log(accEl.log, `Удаление post_id=${h.post_id} → ${e.message}`); }
  }
  historyPosts = historyPosts.filter(h => !(h.acc===accEl.idx && h.ts <= cutoff));
  saveJSON(LS_HISTORY, historyPosts);
  log(accEl.log, `Удалено: ${ok}, ошибок: ${fail}`);
}

// Wiring
for (const el of accEls){
  el.startBtn.addEventListener("click", ()=>startAcc(el));
  el.stopBtn.addEventListener("click", ()=>stopAcc(el));
  el.postOnceBtn.addEventListener("click", ()=>postOnce(el));
  el.sweepBtn.addEventListener("click", ()=>sweepOld(el));
}
restoreCfg();

// Периодический «скуп» по всем аккаунтам раз в час
setInterval(()=>accEls.forEach(el=>sweepOld(el)), 60*60*1000);
